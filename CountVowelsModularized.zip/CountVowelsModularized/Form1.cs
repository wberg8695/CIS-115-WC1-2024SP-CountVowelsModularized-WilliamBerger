namespace CountVowelsModularized
{
    public partial class CountVowelsModularized : Form
    {
        public CountVowelsModularized()
        {
            InitializeComponent();
        }

        private void CountButton_Click(object sender, EventArgs e)
        {
            string input = inputBox.Text;
            outputBox.Text = Main(input).ToString();
        }
        private int Main(string stmt)
        {
            int count = 0;
            for (int x = 0; x < stmt.Length; ++x)
            {
                if (IsVowel(stmt[x]))
                {
                    count = count +1;
                }
            }
            return count;
        }
        private bool IsVowel(char c)
        {
            switch (c)
            {
                case 'A':
                case 'a':
                case 'E':
                case 'e':
                case 'I':
                case 'i':
                case 'O':
                case 'o':
                case 'U':
                case 'u':
                    return true;
                default:
                    return false;
            }
        }
    }
}
