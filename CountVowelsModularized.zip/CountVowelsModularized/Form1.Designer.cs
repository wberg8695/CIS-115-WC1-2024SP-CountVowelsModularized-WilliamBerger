﻿namespace CountVowelsModularized
{
    partial class CountVowelsModularized
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            inputLabel = new Label();
            inputBox = new TextBox();
            countButton = new Button();
            outputBox = new Label();
            yNotVowel = new Label();
            SuspendLayout();
            // 
            // inputLabel
            // 
            inputLabel.AutoSize = true;
            inputLabel.Location = new Point(61, 59);
            inputLabel.Name = "inputLabel";
            inputLabel.Size = new Size(125, 20);
            inputLabel.TabIndex = 0;
            inputLabel.Text = "Enter a statement";
            // 
            // inputBox
            // 
            inputBox.Location = new Point(210, 56);
            inputBox.Name = "inputBox";
            inputBox.Size = new Size(255, 27);
            inputBox.TabIndex = 1;
            // 
            // countButton
            // 
            countButton.Location = new Point(61, 99);
            countButton.Name = "countButton";
            countButton.Size = new Size(125, 29);
            countButton.TabIndex = 2;
            countButton.Text = "Count Vowels";
            countButton.UseVisualStyleBackColor = true;
            countButton.Click += CountButton_Click;
            // 
            // outputBox
            // 
            outputBox.BorderStyle = BorderStyle.Fixed3D;
            outputBox.Location = new Point(210, 103);
            outputBox.Name = "outputBox";
            outputBox.Size = new Size(255, 25);
            outputBox.TabIndex = 3;
            // 
            // yNotVowel
            // 
            yNotVowel.AutoSize = true;
            yNotVowel.Location = new Point(73, 152);
            yNotVowel.Name = "yNotVowel";
            yNotVowel.Size = new Size(375, 20);
            yNotVowel.TabIndex = 4;
            yNotVowel.Text = "For the sake of simplicity, \"Y\" is not considered a vowel.";
            // 
            // CountVowelsModularized
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(526, 201);
            Controls.Add(yNotVowel);
            Controls.Add(outputBox);
            Controls.Add(countButton);
            Controls.Add(inputBox);
            Controls.Add(inputLabel);
            Name = "CountVowelsModularized";
            Text = "Count Vowels Modularized";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label inputLabel;
        private TextBox inputBox;
        private Button countButton;
        private Label outputBox;
        private Label yNotVowel;
    }
}
